window.tinymce = window.tinymce || {
  base:   '/assets/tinymce',
  suffix: ''
};
